<html>
  <head>
     <title>Welcome to HIET</title>
  </head>
  <body>
     <form action=EmpAction.php method=post>
    <pre>
       Ename <input required type=text name=name placeholder="Plz Enter Ename" />

       Salary<input required type=text name=sal placeholder="Plz Enter Salary" />

       D.O.B.<input name="dob" type=date value="2002-01-01" min="1990-01-01" max="2005-12-31" />
    
          <input type=submit value='S a v e ' />

   <a href=Report.php>List of All Employees</a>
   </pre>
  
  </body>
</html>
