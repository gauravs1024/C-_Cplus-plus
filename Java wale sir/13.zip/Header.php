<html>
   <head>
      <title>WELCOME TO HIET COLLEGE</title>
      <link rel=stylesheet href="Design.css" />
   </head>
   <body bgcolor=lightyellow>
   <center><tt><a href="Home.php">Home</a> | <a href="About.php">About us</a> | <a href="Clients.php">Clients</a> | <a href="Contact.php">Contact us</a></tt></center>
   <hr size=2 color=green>