<?php
  include "Header.php";
?>

<tt>
  <center>
   <form class=frm action=Register.php>
    <table width=100% border=0>
     <caption>EMPLOYEE REGISTRATION FORM</caption>
     <tr>
       <td class=lbl>Name</td><td><input class=fld type=text required name=name placeholder="Plz Enter Name" /></td>
       <td class=lbl>Father's Name</td><td><input  class=fld required type=text name=fname placeholder="Plz Enter Father's Name" /></td>
     </tr>
     <tr>
       <td class=lbl>User Id</td><td><input class=fld required type=text name=uid placeholder="Plz Enter ur user id" /></td>
       <td class=lbl>Password</td><td><input required class=fld type=password name=pass placeholder="Plz Enter ur Password" /></td>
     </tr>
     <tr>
       <td class=lbl>D.O.B.</td><td><input class=fld type=date name=dob value="2000-01-01" required /></td>
       <td class=lbl>Mobile</td><td><input class=fld type=number name=mobile placeholder="9990046906" /></td>
     </tr>
     <tr>
       <td class=lbl>Mail Id</td><td><input class=fld type=email name=mailid placeholder="Plz Enter Mail Id" required /></td>
       <td class=lbl>PAN No</td><td><input type=text class=fld name=pan placeholder="AHQPR8723K" /></td>
     </tr>
     <tr>
       <td class=lbl>Address</td><td colspan=3><textarea class=fld style="width:92%;height:50px;" name=addr rows=4 cols=70></textarea></td>
     </tr>
     <tr>
       <td class=lbl>Gender</td><td><select name=ge required class="fld">
                              <option value="">Hello I m ...</option>
                              <option value="Male">Male.</option>
                              <option value="Female">Female.</option>

                          </select>
                       </td>
       <td class=lbl>Aadhaar</td><td><input class=fld type=text name=aadhaar placeholder="1234-1234-1234" /></td>
     </tr>
     <tr>
       <th colspan=4><input class=btn type=submit value=" Sign Up "> <input class=btn type=reset value=" Clear " />
     </tr>
     

    </table> 
   </form>
  </center>
</tt>


<?php
  include "Footer.php";
?>
