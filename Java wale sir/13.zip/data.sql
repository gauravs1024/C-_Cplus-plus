CREATE DATABASE JOB;
USE JOB;

create table tblSecurityQuestion
(
   securityquestionno int(5) primary key auto_increment,
   question varchar(100)
);

create table tblLogin
(
   userid varchar(20) primary key,
   pass varchar(20),
   wmode varchar(20),
   mobile varchar(14),
   dob date,
   securityquestionno int(5) references tblSecurityQuestion(securityquestionno),
   secuityanswer varchar(100),
   status varchar(10),
   createdon datetime
);

create table tblPhoto
(
   id int(5) primary key auto_increment,
   photo longblob
);

create table candProfile
(
   id int(5) primary key auto_increment,
   name varchar(40),
   fname varchar(30),
   mname varchar(30),
   pid int(5) references tblPhoto(id),
   userid varchar(20) references tblLogin(userid),
   dob date,
   gender varchar(20),
   aadhaar varchar(15),
   pan varchar(12),
   modifiedon datetime
);

