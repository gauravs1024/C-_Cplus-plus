<html>
  <head>
     <title>Welcome to HIET</title>
  </head>
  <body>
   <pre>
     <?php
       # we have 3 Types of arrays in PHP
       # normal array - single dim
       $ar = array(10,70,30,20,80,90,15); 
       print_r($ar); // print with recursive - array display
       echo "<br>elements in array - ";
       for($i=0;$i<count($ar);$i++)
         echo $ar[$i],", ";
       echo "<br>elements in array - ";
       foreach($ar as $n)
         echo $n,", ";
       sort($ar); 
       echo "<br>elements in array - ";
       foreach($ar as $n)
         echo $n,", ";
       rsort($ar); 
       echo "<br>elements in array - ";
       foreach($ar as $n)
         echo $n,", ";
     # ASSOCIATIVE ARRAY - same as Map in Java - 
     # value associate with key name 
     $arr = array("aa"=>10,"cc"=>70,"kk"=>30,"dd"=>20,"mm"=>80,"ff"=>90);
     print_r($arr); 
     # all pre define arrays in PHP r associative array
     asort($arr);
     print_r($arr); 
     ksort($arr);
     print_r($arr); 
     sort($arr);
     print_r($arr); 
     
     ?>

   </pre>
  
  </body>
</html>
