<html>
  <head>
     <title>Welcome to HIET</title>
  </head>
  <body>
     <form action=a3.php method=post>
    <pre>
       <input name="dob" type=date value="2002-01-01" min="1990-01-01" max="2005-12-31" />
       Plz Enter any Number <input required type=number min=1 max=100 name=num placeholder="Plz Enter any Number" />
    
          <input type=submit value='Sign In' />
    <?php
       /*
        for get form value in PHP, we have 3 arrays
        $_GET[fieldName] - get value if form method is get
        $_POST[fieldName] - get value if form method is post
        $_REQUEST[fieldName] - get value if form method is get or post 
      */
      if(isset($_POST["num"]))
      {
        $n = $_POST["num"];
        for($i=1,$j=10;$i<=10;$i++,$j--)
        {
          printf("<br> %02d * %02d = %03d  %02d * %02d = %03d",$n,$i,$n*$i,$n,$j,$n*$j);
        }
      }
       
      $d = $_REQUEST["dob"];
      echo "<hr size=3 color=red>";
      echo "<br>ur date of birth is - $d"; 
    ?>
   </pre>
  
  </body>
</html>
