<body bgcolor=lightgreen>
<tt>
<?php
    $nm = $_POST["name"];
    $sl = $_POST["sal"];
    $dob = $_POST["dob"];
    $dd = mysqli_connect("localhost","root","","gaurav",3306);
    $str = "insert into tblEMP(ENAME,SAL,DOB,LASTMODIFIED) VALUES('$nm',$sl,'$dob',NOW())";
    $x = mysqli_query($dd,$str);
    echo "Employee Record Successfully Inserted";

?>
<table border=2 width=100%>
   <tr>
      <th>Empno</th><th>Employee Name</th><th>Salary</th><th>Date Of Birth</th><th>Last Modified</th>
   </tr>

<?php
    $str = "select * from tblEmp";
    $x = mysqli_query($dd,$str);
    $nor = mysqli_num_rows($x); // return number of rows 
    for($i=1;$i<=$nor;$i++)
    {
        echo "<tr>";
        $rs = mysqli_fetch_row($x); // return row 
        foreach($rs as $n)
          echo "<td>$n</td>"; 
        echo "</tr>";
     }

?>
   </tr>

</table>