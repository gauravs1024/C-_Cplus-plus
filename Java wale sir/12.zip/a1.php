<html>
  <head>
     <title>Welcome to HIET</title>
  </head>
  <body>
   <tt>
      Welcome's U<hr size=2 color=red>
     <?php
        for($i=1;$i<=10;$i++)
          echo "Welcome Mayank<br>";
        $a = "Gopesh Shukla";
        echo "Hello $a, Welcome's U";
     ?>

   </tt>
  
  </body>
</html>
